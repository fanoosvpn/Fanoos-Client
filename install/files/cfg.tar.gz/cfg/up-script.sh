#$1 ifname $2 ip $3 subnet $gw
##enabling this may lose your access##ip route replace default dev $1 via $4
ip rule add from 172.16.0.0/24 lookup Fanoos
ip route add default dev $1 via $4 table Fanoos