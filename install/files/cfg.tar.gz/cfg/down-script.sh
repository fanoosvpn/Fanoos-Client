ip rule delete from 172.16.16.0/24 lookup Fanoos
